<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ChMessage;
use Chatify\ChatifyMessenger;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserChatMessageController extends Controller
{
    public function userChats()
    {
        $messages = ChMessage::query()
            ->select('from_id', 'to_id', DB::raw('MAX(created_at) as created_at'),DB::raw('MAX(body) as body'),DB::raw('MAX(id) as id'))
            ->groupBy('from_id', 'to_id')
            ->get();


        return view('admin.zenix.usermodule.userChats',compact('messages'));
    }

    public function userMessageDetailsChats($from_id, $to_id){
        $messages = ChMessage::query()->where('from_id','=',$from_id)->where('to_id','=',$to_id)->get();
        return view('admin.zenix.usermodule.userChatsDetails',compact('messages'));

    }
}

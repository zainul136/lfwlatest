<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreUserRequest;
use App\Models\Country;
use App\Models\Post;
use App\Models\User;
use App\Models\UserInformation;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Application;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\Hash;
use JetBrains\PhpStorm\NoReturn;

class UsersController extends Controller
{
    use  SoftDeletes;

    public  function userInformation(){
        $users = User::query()->with('userInformation')->get();
        return view('admin.zenix.dashboard.userInformation',compact('users'));
    }

    public  function addNewUser(){
        $countries =  Country::all();
        return view('admin.zenix.dashboard.editUser',compact('countries'));
    }

    public function storeNewUser(Request $request): Application|Redirector|RedirectResponse|\Illuminate\Contracts\Foundation\Application
    {

        $validatedData = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|unique:users',
            'phone' => 'nullable|string',
            'date_of_birth' => 'required|date',
            'country' => 'required|string',
            'city' => 'required|string',
            'gender' => 'required|in:Male,Female',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $user = User::create([
            'first_name' => $validatedData['first_name'],
            'last_name' => $validatedData['last_name'],
            'email' => $validatedData['email'],
            'password' => Hash::make($validatedData['password']),
        ]);

        UserInformation::create([
            'user_id' => $user->id,
            'date_of_birth' => $validatedData['date_of_birth'],
            'country' => $validatedData['country'],
            'city' => $validatedData['city'],
            'gender' => $validatedData['gender'],
        ]);

        return redirect('admins/userInformation')->with('success', 'User created successfully');
    }
    public function updateUserRecord(Request $request): Application|Redirector|RedirectResponse|\Illuminate\Contracts\Foundation\Application
    {

        $validatedData = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $request->user_id,
            'date_of_birth' => 'required|date',
            'country' => 'required|string',
        ]);

        $user = User::findOrFail($request->user_id);
        $user->update([
            'first_name' => $validatedData['first_name'],
            'last_name' => $validatedData['last_name'],
            'email' => $validatedData['email'],
        ]);

        $userInformation = UserInformation::where('user_id', $request->user_id)->first();
        $userInformation->update([
            'date_of_birth' => $validatedData['date_of_birth'],
            'country' => $validatedData['country'],
        ]);

        return redirect('admins/userInformation')->with('success', 'User updated successfully');
    }


    public function softDelete(User $user)
    {
        $user->delete();
        return redirect()->route('user-information')->with('message', 'User has been soft-deleted.');
    }

    public function getDeletedUser(){
        $users = User::onlyTrashed()->get();

        return view('admin.zenix.dashboard.deletedUser',compact('users'));
    }

    public function restoreUser($userId)
    {
        $user = User::withTrashed()->find($userId);

        if ($user) {
            $user->restore();
            return redirect()->route('user-information')->with('success', 'User restored successfully');
        } else {
            return redirect()->route('user-information')->with('error', 'User not found');
        }
    }

    public function permanentDeletedUser($id)
    {
        $user = User::query()->findOrFail($id);
        if ($user){

            $user->delete();


        }
        return redirect()->route('user-information')->with('message', 'User has been permanently deleted.');
    }


}

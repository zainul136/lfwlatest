<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DeathConfirmation;
use App\Models\Post;
use App\Models\User;
use App\Models\UserRelationship;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Foundation\Application;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;

class DeceasedController extends Controller
{
    public function deceasedRequest(): View|Application|Factory|\Illuminate\Contracts\Foundation\Application
    {
        $deceaseUsers = DeathConfirmation::query()->where('is_alive','=',0)->where('confirmation_status','=',1)->with('user')->get();

        return view('admin.zenix.dashboard.deceasedRequest',compact('deceaseUsers'));

    }

    public function downloadDeathCertificate($filename): \Illuminate\Http\Response
    {
        $filePath = public_path('death_certificate/' . $filename);
        if (file_exists($filePath)) {
            $fileContent = file_get_contents($filePath);
            $mimeType = mime_content_type($filePath);
            $originalName = pathinfo($filePath, PATHINFO_FILENAME);

            return response()->make($fileContent, 200, [
                'Content-Type' => $mimeType,
                'Content-Disposition' => "attachment; filename={$originalName}.{$filename}"
            ]);
        }

        return response('File not found', 404);
    }

    public function sendNotification($id)
    {
        $deathPerson = DeathConfirmation::with(['user.userInformation', 'user.userRelationships.relationship'])
            ->findOrFail($id);

        if ($deathPerson) {
            $deathPersonRequested = json_decode($deathPerson->confirmations_from);
            $userRelationships = $deathPerson->user->userRelationships;

            $familyMembers = User::whereIn('id', $userRelationships->pluck('relative_id'))
                ->with(['userInformation', 'relationships'])
                ->get();
    }

        return view('admin.zenix.dashboard.sendNotification',compact('deathPersonRequested','deathPerson','familyMembers'));
    }


    public function deceasedPostDetails($id)
    {
        $post = Post::query()->where('id','=',$id)
            ->with(['user.userInformation','PostText','postImage','postVideo','postDocument','tags','postAudio'])
            ->first();
        return view('admin.zenix.dashboard.editPrivatePost',compact('post'));
    }

}
